//version 0.4 2077ver0.4

function NBI_trans_mouseover(obj) {
    obj.style.backgroundImage = 'Linear-gradient(45deg, #1B6EA6, #22AF6C)';
}

function NBI_trans_mouseout(obj) {
    obj.style.backgroundImage = null;
}

function CBB_trans_mouseover(obj) {
    obj.style.backgroundColor = '#124567';
}

function CBB_trans_mouseout(obj) {
    obj.style.backgroundColor = '#1B6EA6';
}

function CBB_trans_click(obj) {
    obj.style.backgroundImage = 'Linear-gradient(45deg, #1B6EA6, #22AF6C)';
}